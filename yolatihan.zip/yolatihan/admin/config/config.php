<?php

define('baseurl', 'http://localhost/yolatihan/public');